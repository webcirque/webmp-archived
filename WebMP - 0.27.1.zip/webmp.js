// Thread
function refresherThreadFunc() {
	// Show time
	let currentMin = Math.floor(video.currentTime / 60).toString();
	while (currentMin.length < 2) {
		currentMin = "0" + currentMin;
	}
	let currentSec = Math.floor(video.currentTime % 60).toString();
	while (currentSec.length < 2) {
		currentSec = "0" + currentSec;
	}
	gui.timeNow.innerHTML = currentMin + ":" + currentSec;
	currentMin = Math.floor(video.duration / 60).toString();
	while (currentMin.length < 2) {
		currentMin = "0" + currentMin;
	}
	currentSec = Math.floor(video.duration % 60).toString();
	while (currentSec.length < 2) {
		currentSec = "0" + currentSec;
	}
	gui.timeAll.innerHTML = currentMin + ":" + currentSec;
	// Show FPS
	fps.last = fps.curr;
	fps.curr = new Date();
	fps.innerHTML = (Math.round(1000 / (timeSt(fps.curr) - timeSt(fps.last)))).toString() + "FPS";
	// Show video playing
	if (video.paused) {
		btn.play.style.display = "";
		btn.pause.style.display = "none";
		if (video.readyState == 4) {
			gui.pio.style.display = "";
		}
		else {
			gui.pio.style.display = "none";
		}
	}
	else {
		btn.play.style.display = "none";
		btn.pause.style.display = "";
		gui.pio.style.display = "none";
	}
	gui.timeBar.style.width = (innerWidth - 72) + "px";
	gui.timeP.style.width = Math.floor(video.currentTime / video.duration * (innerWidth - 70)) + "px";
	let vcs = video.src.split("/");
	if (video.readyState == 4) {
		gui.title.innerHTML = decodeURI(vcs[vcs.length - 1]);
		gui.loadAni.style.display = "none";
	}
	else if (video.readyState == 3) {
		gui.title.innerHTML = decodeURI(vcs[vcs.length - 1]) + " - " + lang.videoCanNextFrame;
		gui.loadAni.style.display = "";
	}
	else {
		gui.title.innerHTML = decodeURI(vcs[vcs.length - 1]) + " - " + lang.videoDecoding + video.readyState;
		gui.loadAni.style.display = "";
	}
}
// Document loader
document.onreadystatechange = function() {
	if (document.readyState.toLowerCase() == "interactive") {
		console.log("WebMP started loading...");
		// Load elements
		document.body.tabIndex = "-1";
		video = document.getElementsByTagName("video")[0];
		audio = document.getElementsByTagName("audio")[0];
		let files = document.getElementById("fbtn");
		fps = document.getElementById("FPS");
		btn = {};
		gui = {};
		btn.play = document.getElementById("playbtn");
		btn.pause = document.getElementById("pausebtn");
		gui.title = document.getElementById("title");
		gui.timeNow = document.getElementById("time-now");
		gui.timeAll = document.getElementById("time-all");
		gui.timeBar = document.getElementById("time-bar");
		gui.timeP = document.getElementById("time-played");
		gui.pio = document.getElementById("play-if-ok");
		gui.loadAni = document.getElementById("loading-anime");
		// On resize
		window.onresize = function() {
			gui.loadAni.style.top = (innerHeight / 2 - 36) + "px";
			gui.loadAni.style.left = (innerWidth / 2 - 36) + "px";
		}
		gui.loadAni.style.top = (innerHeight / 2 - 36) + "px";
		gui.loadAni.style.left = (innerWidth / 2 - 36) + "px";
		// Pre FPS announce
		fps.last = new Date();
		fps.curr = new Date();
		// Load refresher
		refresherThread = setInterval(refresherThreadFunc, 25);
		// Load media
		if (window.TabSearch) {
			let info = TabSearch(location.search);
			if (info.file) {
				video.src = info.file;
				video.volume = 0;
				audio.src = info.file;
			}
			if (info.start) {
				video.currentTime = parseFloat(info.start);
			}
			else {
				gui.title.innerHTML = lang.noArgs;
			}
		}
		// Load buttons
		btn.play.onmouseup = function() {
			video.play();
			audio.play();
		}
		btn.pause.onmouseup = function() {
			video.pause();
			audio.pause();
		}
		gui.pio.onmouseup = function() {
			video.play();
			audio.play();
		}
		// Smart resource
		document.body.onblur = function() {
			clearInterval(refresherThread);
			refresherThread = setInterval(refresherThreadFunc, 1000);
			console.log(lang.resourceSlowed);
			document.body.onfocus = function() {
				clearInterval(refresherThread);
				refresherThread = setInterval(refresherThreadFunc, 25);
				console.log(lang.resourceRegained);
			}
		}
	}
}
//Supporter
timeSt = function(time) {
	if (time.constructor == Date) {
		let month = time.getMonth();
		let year = time.getFullYear();
		let timestamp = time.getMilliseconds() + time.getSeconds() * 1000 + time.getMinutes() * 60000 + time.getHours() * 3600000 + time.getDate() * 86400000 + time.getMonth() * 2592000000;
		if (month > 2) {
			if (year % 4 == 0) {
				if (year % 400 == 0) {
					timestamp += 86400000;
				}
				else if (year % 100 != 0) {
					timestamp += 86400000;
				}
			}
			if (month >= 11) {
				timestamp += 345600000;
			}
			else if (month >= 9) {
				timestamp += 259200000;
			}
			else if (month == 8) {
				timestamp += 172800000;
			}
			else if (month >= 6) {
				timestamp += 86400000;
			}
			else if (month == 3) {
				timestamp -= 86400000;
			}
		}
		else if (month == 2) {
			timestamp += 86400000;
		}
		return timestamp;
	}
}
// Language
if (window.navigator) {
	if (window.navigator.language) {
		switch (navigator.language) {
			case "zh":
			case "zh-CN":
				console.log("Language: Chinese Simplified");
				lang = {
					"noArgs": "文件未指定",
					"resourceSlowed": "已智能释放资源",
					"resourceRegained": "资源已重载",
					"videoDecoding": "媒体解码中 : ",
					"videoCanNextFrame": "即将就绪"
				}
				break;
			default:
				console.log("Language: Chinese Simplified");
				lang = {
					"noArgs": "File not set",
					"resourceSlowed": "Slowed down refreshing.",
					"resourceRegained": "Refreshing sped up.",
					"videoDecoding": "Decoding media : ",
					"videoCanNextFrame": "Almost ready"
				}
		}
	}
}