if (window.top == window) {
	location.href = "index.htm";
}