// Resize window
wmpResizeWindow = function () {
	wmpDisplay.style.width = (innerWidth - 48).toString() + "px";
}

// Load document
document.onreadystatechange = function () {
	if (this.readyState.toLowerCase() == "interactive") {
		// Load elements
		wmpMenuBar = document.getElementById("menubar");
		wmpDisplay = document.getElementById("display");
		window.onresize = wmpResizeWindow;
		wmpResizeWindow();
	}
}