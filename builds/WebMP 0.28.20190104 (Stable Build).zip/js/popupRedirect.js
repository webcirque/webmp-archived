onload = function () {
	open("index.htm");
};